import json
import os
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.font import Font
import threading
import time

class ProductivityApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced Task Manager")
        self.root.geometry("1100x650")
        self.root.minsize(800, 500)
        
        # Clean color scheme
        self.colors = {
            'bg': '#1e1e1e',           # Dark background
            'fg': '#ffffff',           # White text
            'accent': '#007acc',       # Blue accent
            'success': '#28a745',      # Green
            'warning': '#ffc107',      # Yellow
            'error': '#dc3545',        # Red
            'surface': '#2d2d30',      # Card background
            'border': '#3e3e42'        # Border color
        }
        
        # Configure root window
        self.root.configure(bg=self.colors['bg'])
        
        # Apply clean theme
        self.setup_styles()
        
        self.data_file = "tasks.json"
        self.tasks = self.load_tasks()
        
        # Overlay system: 0=Normal(100%), 1=Light(80%), 2=Transparent(20%)
        self.overlay_mode = 0
        self.opacity_levels = [1.0, 0.8, 0.2]
        self.overlay_names = ["Normal", "Light", "Transparent"]
        
        # Set initial opacity
        self.root.attributes("-alpha", self.opacity_levels[self.overlay_mode])
        
        # Create clean fonts
        self.create_fonts()
        
        # Configure main layout
        self.root.grid_columnconfigure(0, weight=2)  # Task panel
        self.root.grid_columnconfigure(1, weight=1)  # Smart panel
        self.root.grid_rowconfigure(1, weight=1)
        
        # Create interface
        self.create_header()
        self.create_main_interface()
        self.create_footer()
        
        # Initialize data
        self.update_stats()
        self.update_smart_view()
        
        # Load configuration
        self.load_config()
        
        # Setup events
        self.setup_events()

    def setup_styles(self):
        """Configure clean ttk styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Frame styles
        style.configure('Main.TFrame', background=self.colors['bg'])
        style.configure('Card.TFrame', background=self.colors['surface'], relief='solid', borderwidth=1)
        style.configure('Header.TFrame', background=self.colors['accent'])
        
        # Label styles
        style.configure('Title.TLabel', background=self.colors['bg'], foreground=self.colors['fg'], 
                       font=('Segoe UI', 14, 'bold'))
        style.configure('Header.TLabel', background=self.colors['accent'], foreground='white',
                       font=('Segoe UI', 12, 'bold'))
        style.configure('Body.TLabel', background=self.colors['bg'], foreground=self.colors['fg'],
                       font=('Segoe UI', 10))
        style.configure('Card.TLabel', background=self.colors['surface'], foreground=self.colors['fg'],
                       font=('Segoe UI', 10))
        
        # Button styles
        style.configure('Accent.TButton', background=self.colors['accent'], foreground='white',
                       font=('Segoe UI', 9, 'bold'), borderwidth=0)
        style.configure('Success.TButton', background=self.colors['success'], foreground='white',
                       font=('Segoe UI', 9), borderwidth=0)
        style.configure('Warning.TButton', background=self.colors['warning'], foreground='black',
                       font=('Segoe UI', 9), borderwidth=0)
        style.configure('Error.TButton', background=self.colors['error'], foreground='white',
                       font=('Segoe UI', 9), borderwidth=0)
        
        # Entry style
        style.configure('Clean.TEntry', fieldbackground=self.colors['surface'], 
                       foreground=self.colors['fg'], borderwidth=1, insertcolor=self.colors['fg'])
        
        # Treeview styles
        style.configure('Clean.Treeview', background=self.colors['surface'], 
                       foreground=self.colors['fg'], fieldbackground=self.colors['surface'],
                       borderwidth=0, font=('Segoe UI', 9))
        style.configure('Clean.Treeview.Heading', background=self.colors['accent'],
                       foreground='white', font=('Segoe UI', 10, 'bold'))
        
        # LabelFrame style
        style.configure('Clean.TLabelframe', background=self.colors['bg'], 
                       borderwidth=1, relief='solid')
        style.configure('Clean.TLabelframe.Label', background=self.colors['bg'],
                       foreground=self.colors['accent'], font=('Segoe UI', 11, 'bold'))

    def create_fonts(self):
        """Create font objects"""
        self.fonts = {
            'title': Font(family="Segoe UI", size=14, weight="bold"),
            'header': Font(family="Segoe UI", size=12, weight="bold"),
            'body': Font(family="Segoe UI", size=10),
            'small': Font(family="Segoe UI", size=9)
        }

    def create_header(self):
        """Create clean header"""
        header = ttk.Frame(self.root, style='Header.TFrame', padding=(20, 15))
        header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=2, pady=2)
        header.grid_columnconfigure(1, weight=1)
        
        # Title
        ttk.Label(header, text="Enhanced Task Manager", style='Header.TLabel').grid(row=0, column=0)
        
        # Status
        self.status_label = ttk.Label(header, text="Normal Mode", style='Header.TLabel')
        self.status_label.grid(row=0, column=1, padx=20)
        
        # Overlay button
        ttk.Button(header, text="Overlay Mode", command=self.cycle_overlay_mode,
                  style='Warning.TButton', width=14).grid(row=0, column=2)

    def create_main_interface(self):
        """Create main content area"""
        # Task management panel
        task_panel = ttk.LabelFrame(self.root, text="Task Management", 
                                   style='Clean.TLabelframe', padding=20)
        task_panel.grid(row=1, column=0, sticky="nsew", padx=(10, 5), pady=(5, 10))
        task_panel.grid_columnconfigure(0, weight=1)
        task_panel.grid_rowconfigure(1, weight=1)
        
        self.create_task_form(task_panel)
        self.create_task_list(task_panel)
        self.create_task_actions(task_panel)
        
        # Stats
        self.stats_label = ttk.Label(task_panel, text="", style='Body.TLabel')
        self.stats_label.grid(row=3, column=0, sticky="w", pady=(15, 0))
        
        # Smart panel
        smart_panel = ttk.LabelFrame(self.root, text="Priority Tasks", 
                                    style='Clean.TLabelframe', padding=20)
        smart_panel.grid(row=1, column=1, sticky="nsew", padx=(5, 10), pady=(5, 10))
        smart_panel.grid_columnconfigure(0, weight=1)
        smart_panel.grid_rowconfigure(0, weight=1)
        
        self.create_smart_view(smart_panel)
        
        # Smart stats
        self.smart_stats_label = ttk.Label(smart_panel, text="", style='Body.TLabel')
        self.smart_stats_label.grid(row=1, column=0, sticky="w", pady=(15, 0))

    def create_task_form(self, parent):
        """Create clean task entry form"""
        form = ttk.Frame(parent, style='Card.TFrame', padding=15)
        form.grid(row=0, column=0, sticky="ew", pady=(0, 20))
        form.grid_columnconfigure(1, weight=1)
        
        ttk.Label(form, text="Add New Task", style='Card.TLabel', 
                 font=self.fonts['header']).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 15))
        
        # Description
        ttk.Label(form, text="Description:", style='Card.TLabel').grid(row=1, column=0, sticky="w", padx=(0, 10))
        self.desc_entry = ttk.Entry(form, style='Clean.TEntry', font=self.fonts['body'])
        self.desc_entry.grid(row=1, column=1, columnspan=2, sticky="ew", pady=5)
        
        # Priority
        ttk.Label(form, text="Priority:", style='Card.TLabel').grid(row=2, column=0, sticky="w", padx=(0, 10), pady=(10, 0))
        
        priority_frame = ttk.Frame(form, style='Card.TFrame')
        priority_frame.grid(row=2, column=1, sticky="w", pady=(10, 0))
        
        self.priority_var = tk.StringVar(value="medium")
        ttk.Radiobutton(priority_frame, text="High", variable=self.priority_var, value="high").pack(side="left", padx=(0, 15))
        ttk.Radiobutton(priority_frame, text="Medium", variable=self.priority_var, value="medium").pack(side="left", padx=(0, 15))
        ttk.Radiobutton(priority_frame, text="Low", variable=self.priority_var, value="low").pack(side="left")
        
        # Due date
        ttk.Label(form, text="Due Date:", style='Card.TLabel').grid(row=3, column=0, sticky="w", padx=(0, 10), pady=(10, 0))
        self.due_entry = ttk.Entry(form, style='Clean.TEntry', width=12)
        self.due_entry.grid(row=3, column=1, sticky="w", pady=(10, 0))
        self.due_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        
        # Add button
        ttk.Button(form, text="Add Task", command=self.add_task,
                  style='Accent.TButton').grid(row=3, column=2, sticky="e", pady=(10, 0), padx=(10, 0))
        
        self.desc_entry.bind('<Return>', lambda e: self.add_task())

    def create_task_list(self, parent):
        """Create clean task list"""
        list_frame = ttk.Frame(parent, style='Card.TFrame', padding=10)
        list_frame.grid(row=1, column=0, sticky="nsew", pady=(0, 20))
        list_frame.grid_columnconfigure(0, weight=1)
        list_frame.grid_rowconfigure(0, weight=1)
        
        columns = ("id", "description", "priority", "due_date", "status")
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings", 
                                style='Clean.Treeview', height=12)
        
        # Configure columns
        self.tree.heading("id", text="ID")
        self.tree.heading("description", text="Task Description")
        self.tree.heading("priority", text="Priority")
        self.tree.heading("due_date", text="Due Date")
        self.tree.heading("status", text="Status")
        
        self.tree.column("id", width=40, anchor="center")
        self.tree.column("description", width=280)
        self.tree.column("priority", width=70, anchor="center")
        self.tree.column("due_date", width=90, anchor="center")
        self.tree.column("status", width=80, anchor="center")
        
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        self.tree.bind("<Double-1>", self.edit_task)
        self.refresh_task_list()

    def create_task_actions(self, parent):
        """Create task action buttons"""
        actions = ttk.Frame(parent, style='Card.TFrame', padding=10)
        actions.grid(row=2, column=0, sticky="ew")
        
        ttk.Button(actions, text="Complete", command=self.complete_task,
                  style='Success.TButton').pack(side="left", padx=(0, 10))
        ttk.Button(actions, text="Edit", command=lambda: self.edit_task(None),
                  style='Accent.TButton').pack(side="left", padx=(0, 10))
        ttk.Button(actions, text="Delete", command=self.delete_task,
                  style='Error.TButton').pack(side="left", padx=(0, 10))
        
        ttk.Button(actions, text="Clear Completed", command=self.clear_completed,
                  style='Warning.TButton').pack(side="right")

    def create_smart_view(self, parent):
        """Create priority tasks view"""
        smart_frame = ttk.Frame(parent, style='Card.TFrame', padding=10)
        smart_frame.grid(row=0, column=0, sticky="nsew")
        smart_frame.grid_columnconfigure(0, weight=1)
        smart_frame.grid_rowconfigure(0, weight=1)
        
        smart_columns = ("description", "priority", "due_date")
        self.smart_tree = ttk.Treeview(smart_frame, columns=smart_columns, show="headings",
                                      style='Clean.Treeview', height=12)
        
        self.smart_tree.heading("description", text="Task")
        self.smart_tree.heading("priority", text="Priority")
        self.smart_tree.heading("due_date", text="Due")
        
        self.smart_tree.column("description", width=180)
        self.smart_tree.column("priority", width=60, anchor="center")
        self.smart_tree.column("due_date", width=70, anchor="center")
        
        smart_scrollbar = ttk.Scrollbar(smart_frame, orient="vertical", command=self.smart_tree.yview)
        self.smart_tree.configure(yscrollcommand=smart_scrollbar.set)
        
        self.smart_tree.grid(row=0, column=0, sticky="nsew")
        smart_scrollbar.grid(row=0, column=1, sticky="ns")

    def create_footer(self):
        """Create footer with current mode info"""
        footer = ttk.Frame(self.root, style='Card.TFrame', padding=(20, 10))
        footer.grid(row=2, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 10))
        footer.grid_columnconfigure(1, weight=1)
        
        ttk.Label(footer, text="Press Ctrl+Shift+Q to cycle overlay modes", 
                 style='Card.TLabel').grid(row=0, column=0)
        
        self.time_label = ttk.Label(footer, text="", style='Card.TLabel')
        self.time_label.grid(row=0, column=1, sticky="e")
        self.update_time()

    def update_time(self):
        """Update time display"""
        current_time = datetime.now().strftime("%H:%M:%S")
        self.time_label.config(text=current_time)
        self.root.after(1000, self.update_time)

    def cycle_overlay_mode(self):
        """Cycle through the 3 overlay modes"""
        self.overlay_mode = (self.overlay_mode + 1) % 3
        opacity = self.opacity_levels[self.overlay_mode]
        name = self.overlay_names[self.overlay_mode]
        
        # Apply opacity
        self.root.attributes("-alpha", opacity)
        
        # Set topmost for transparent modes
        if self.overlay_mode > 0:
            self.root.attributes("-topmost", True)
        else:
            self.root.attributes("-topmost", False)
        
        # Update status
        self.status_label.config(text=f"{name} Mode ({int(opacity*100)}%)")
        
        # Save configuration
        self.save_config()
        
        print(f"Overlay mode: {name} ({int(opacity*100)}% opacity)")

    def setup_events(self):
        """Setup event handlers"""
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.bind_all("<Control-Shift-q>", lambda e: self.cycle_overlay_mode())
        self.root.bind_all("<Control-Shift-Q>", lambda e: self.cycle_overlay_mode())

    def save_config(self):
        """Save configuration"""
        config = {
            "overlay_mode": self.overlay_mode,
            "window_geometry": self.root.geometry()
        }
        
        try:
            with open("config.json", "w") as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")

    def load_config(self):
        """Load saved configuration"""
        try:
            if os.path.exists("config.json"):
                with open("config.json", "r") as f:
                    config = json.load(f)
                
                self.overlay_mode = config.get("overlay_mode", 0)
                opacity = self.opacity_levels[self.overlay_mode]
                name = self.overlay_names[self.overlay_mode]
                
                self.root.attributes("-alpha", opacity)
                if self.overlay_mode > 0:
                    self.root.attributes("-topmost", True)
                
                self.status_label.config(text=f"{name} Mode ({int(opacity*100)}%)")
                
        except Exception as e:
            print(f"Error loading config: {e}")

    def on_closing(self):
        """Handle application closing"""
        try:
            self.save_config()
            self.save_tasks()
        except Exception as e:
            print(f"Error during closing: {e}")
        finally:
            self.root.quit()

    # Task Management Methods
    def load_tasks(self):
        """Load tasks from file"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    tasks = json.load(f)
                for task in tasks:
                    if 'created_at' in task:
                        try:
                            task['created_at_dt'] = datetime.strptime(task['created_at'], "%Y-%m-%d %H:%M:%S")
                        except ValueError:
                            task['created_at_dt'] = datetime.now()
                    if 'due_date' in task and task['due_date']:
                        try:
                            task['due_date_dt'] = datetime.strptime(task['due_date'], "%Y-%m-%d")
                        except ValueError:
                            task['due_date'] = ""
                return tasks
            except Exception as e:
                print(f"Error loading tasks: {e}")
        return []

    def save_tasks(self):
        """Save tasks to file"""
        try:
            save_tasks = []
            for task in self.tasks:
                save_task = task.copy()
                if 'created_at_dt' in save_task:
                    del save_task['created_at_dt']
                if 'due_date_dt' in save_task:
                    del save_task['due_date_dt']
                save_tasks.append(save_task)
            
            with open(self.data_file, 'w') as f:
                json.dump(save_tasks, f, indent=2)
        except Exception as e:
            print(f"Error saving tasks: {e}")

    def add_task(self):
        """Add new task"""
        description = self.desc_entry.get().strip()
        if not description:
            messagebox.showerror("Error", "Please enter a task description.")
            return
        
        due_date = self.due_entry.get().strip()
        priority = self.priority_var.get()
        
        if due_date:
            try:
                datetime.strptime(due_date, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Please enter date in YYYY-MM-DD format.")
                return
        
        task_id = len(self.tasks) + 1
        while any(task['id'] == task_id for task in self.tasks):
            task_id += 1
        
        new_task = {
            'id': task_id,
            'description': description,
            'priority': priority,
            'due_date': due_date,
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'completed': False,
            'completed_at': None
        }
        
        new_task['created_at_dt'] = datetime.now()
        if due_date:
            new_task['due_date_dt'] = datetime.strptime(due_date, "%Y-%m-%d")
        
        self.tasks.append(new_task)
        self.save_tasks()
        self.refresh_task_list()
        self.update_stats()
        self.update_smart_view()
        
        # Clear form
        self.desc_entry.delete(0, tk.END)
        self.priority_var.set("medium")
        self.due_entry.delete(0, tk.END)
        self.due_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))

    def complete_task(self):
        """Mark task as completed"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a task to complete.")
            return
        
        item = selected[0]
        task_id = int(self.tree.item(item, "values")[0])
        
        for task in self.tasks:
            if task['id'] == task_id:
                task['completed'] = True
                task['completed_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                break
        
        self.save_tasks()
        self.refresh_task_list()
        self.update_stats()
        self.update_smart_view()

    def delete_task(self):
        """Delete selected task"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a task to delete.")
            return
        
        if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this task?"):
            item = selected[0]
            task_id = int(self.tree.item(item, "values")[0])
            
            self.tasks = [task for task in self.tasks if task['id'] != task_id]
            self.save_tasks()
            self.refresh_task_list()
            self.update_stats()
            self.update_smart_view()

    def clear_completed(self):
        """Clear all completed tasks"""
        completed_count = sum(1 for task in self.tasks if task['completed'])
        if completed_count == 0:
            messagebox.showinfo("Info", "No completed tasks to clear.")
            return
        
        if messagebox.askyesno("Confirm", f"Delete {completed_count} completed tasks?"):
            self.tasks = [task for task in self.tasks if not task['completed']]
            self.save_tasks()
            self.refresh_task_list()
            self.update_stats()
            self.update_smart_view()

    def edit_task(self, event):
        """Edit selected task"""
        selected = self.tree.selection()
        if not selected:
            if event:
                messagebox.showwarning("Warning", "Please select a task to edit.")
            return
        
        item = selected[0]
        task_id = int(self.tree.item(item, "values")[0])
        task = next((t for t in self.tasks if t['id'] == task_id), None)
        
        if not task:
            return
        
        # Create edit dialog
        dialog = tk.Toplevel(self.root)
        dialog.title("Edit Task")
        dialog.geometry("400x250")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.configure(bg=self.colors['bg'])
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (dialog.winfo_screenheight() // 2) - (250 // 2)
        dialog.geometry(f"400x250+{x}+{y}")
        
        main_frame = ttk.Frame(dialog, style='Card.TFrame', padding=20)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        ttk.Label(main_frame, text="Edit Task", style='Title.TLabel').pack(pady=(0, 20))
        
        # Description
        ttk.Label(main_frame, text="Description:", style='Body.TLabel').pack(anchor="w")
        desc_entry = ttk.Entry(main_frame, style='Clean.TEntry', font=self.fonts['body'], width=40)
        desc_entry.pack(fill="x", pady=(5, 15))
        desc_entry.insert(0, task['description'])
        
        # Priority
        ttk.Label(main_frame, text="Priority:", style='Body.TLabel').pack(anchor="w")
        priority_var = tk.StringVar(value=task['priority'])
        priority_frame = ttk.Frame(main_frame, style='Card.TFrame')
        priority_frame.pack(fill="x", pady=(5, 15))
        
        ttk.Radiobutton(priority_frame, text="High", variable=priority_var, value="high").pack(side="left", padx=(0, 15))
        ttk.Radiobutton(priority_frame, text="Medium", variable=priority_var, value="medium").pack(side="left", padx=(0, 15))
        ttk.Radiobutton(priority_frame, text="Low", variable=priority_var, value="low").pack(side="left")
        
        # Due date
        ttk.Label(main_frame, text="Due Date (YYYY-MM-DD):", style='Body.TLabel').pack(anchor="w")
        due_entry = ttk.Entry(main_frame, style='Clean.TEntry', font=self.fonts['body'], width=15)
        due_entry.pack(anchor="w", pady=(5, 20))
        due_entry.insert(0, task['due_date'])
        
        def save_changes():
            new_desc = desc_entry.get().strip()
            if not new_desc:
                messagebox.showerror("Error", "Description cannot be empty.")
                return
            
            new_due_date = due_entry.get().strip()
            if new_due_date:
                try:
                    datetime.strptime(new_due_date, "%Y-%m-%d")
                except ValueError:
                    messagebox.showerror("Error", "Please enter date in YYYY-MM-DD format.")
                    return
            
            task['description'] = new_desc
            task['priority'] = priority_var.get()
            task['due_date'] = new_due_date
            
            if task['due_date']:
                task['due_date_dt'] = datetime.strptime(task['due_date'], "%Y-%m-%d")
            elif 'due_date_dt' in task:
                del task['due_date_dt']
            
            self.save_tasks()
            self.refresh_task_list()
            self.update_stats()
            self.update_smart_view()
            dialog.destroy()
        
        # Buttons
        btn_frame = ttk.Frame(main_frame, style='Card.TFrame')
        btn_frame.pack(fill="x", pady=(20, 0))
        
        ttk.Button(btn_frame, text="Save", command=save_changes,
                  style='Success.TButton').pack(side="right", padx=(10, 0))
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy,
                  style='Error.TButton').pack(side="right")

    def refresh_task_list(self):
        """Refresh task list display"""
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for task in sorted(self.tasks, key=lambda x: x.get('created_at_dt', datetime.now()), reverse=True):
            status = "Complete" if task['completed'] else "Pending"
            values = (
                task['id'],
                task['description'][:45] + ("..." if len(task['description']) > 45 else ""),
                task['priority'].title(),
                task['due_date'] or "-",
                status
            )
            self.tree.insert("", "end", values=values)

    def update_stats(self):
        """Update task statistics"""
        total = len(self.tasks)
        completed = sum(1 for task in self.tasks if task['completed'])
        pending = total - completed
        high_priority = sum(1 for task in self.tasks if task['priority'] == 'high' and not task['completed'])
        
        today = datetime.now().date()
        overdue = sum(1 for task in self.tasks 
                     if not task['completed'] and task.get('due_date_dt') 
                     and task['due_date_dt'].date() < today)
        
        stats_text = f"Total: {total} | Completed: {completed} | Pending: {pending} | High Priority: {high_priority}"
        if overdue > 0:
            stats_text += f" | Overdue: {overdue}"
        
        self.stats_label.config(text=stats_text)

    def update_smart_view(self):
        """Update priority tasks view"""
        for item in self.smart_tree.get_children():
            self.smart_tree.delete(item)
        
        pending_tasks = [task for task in self.tasks if not task['completed']]
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        pending_tasks.sort(key=lambda x: (
            priority_order.get(x['priority'], 3),
            x.get('due_date_dt', datetime.max)
        ))
        
        for task in pending_tasks[:8]:
            description = task['description'][:25] + ("..." if len(task['description']) > 25 else "")
            self.smart_tree.insert("", "end", values=(
                description,
                task['priority'].title(),
                task['due_date'] or "-"
            ))
        
        today = datetime.now().date()
        overdue_count = sum(1 for task in pending_tasks 
                           if task.get('due_date_dt') and task['due_date_dt'].date() < today)
        due_today = sum(1 for task in pending_tasks 
                       if task.get('due_date_dt') and task['due_date_dt'].date() == today)
        
        smart_stats = f"Top {min(len(pending_tasks), 8)} tasks | Overdue: {overdue_count} | Due Today: {due_today}"
        self.smart_stats_label.config(text=smart_stats)


def main():
    """Main application entry point"""
    root = tk.Tk()
    app = ProductivityApp(root)
    
    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (1100 // 2)
    y = (root.winfo_screenheight() // 2) - (650 // 2)
    root.geometry(f"1100x650+{x}+{y}")
    
    print("Enhanced Task Manager started!")
    print("Overlay modes: Normal (100%) -> Light (80%) -> Transparent (20%)")
    print("Press Ctrl+Shift+Q or click 'Overlay Mode' to cycle modes")
    
    root.mainloop()


if __name__ == "__main__":
    main()