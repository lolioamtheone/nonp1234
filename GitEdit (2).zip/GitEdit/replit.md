# Enhanced Task Manager

## Overview

This is a cross-platform Python desktop productivity application built with Tkinter that provides advanced task management capabilities with sophisticated window management features. The application offers multiple display modes including overlay, docking, and transparent controls, making it highly adaptable to different workflow needs.

## Recent Changes (August 12, 2025)

- **Complete Rewrite**: Converted from Windows-specific version to cross-platform Python using only standard libraries
- **Docking System**: Implemented window docking to screen edges (left, right, top, bottom)
- **Overlay Mode**: Added transparent overlay functionality with stay-on-top behavior
- **Keyboard Shortcuts**: Integrated Ctrl+Shift+Q hotkey for overlay toggle
- **Enhanced UI**: Added status indicators and window control buttons
- **Configuration Persistence**: Automatic saving and loading of window states and preferences

## User Preferences

Preferred communication style: Simple, everyday language.
Project Focus: Desktop productivity application with HUD-like docking and overlay capabilities.

## System Architecture

### Frontend Architecture
The application uses Tkinter as the primary GUI framework with a modular design pattern. The main interface is structured with a two-column layout - task management on the left and task lists on the right. Custom fonts and responsive grid layouts ensure a professional appearance that scales with window resizing.

### Window Management System
A sophisticated window management system leverages the Windows API through the `ctypes` and `win32gui` libraries. This enables advanced features like:
- **Overlay Mode**: Transparent, click-through window that stays on top
- **Docking System**: Snap-to-edge functionality for left, right, top, and bottom screen edges
- **Opacity Control**: Adjustable transparency levels for the window
- **Smart Positioning**: Automatic snap detection with configurable thresholds

### System Tray Integration
The application includes comprehensive system tray functionality using the `pystray` library. This provides:
- Custom icon generation using PIL for drawing
- Context menu with window management options
- Background operation capability
- Quick access to all major features

### Configuration Management
A JSON-based configuration system stores user preferences including:
- Window geometry and positioning
- Dock settings and behavior
- Overlay transparency levels
- Hotkey assignments
- Tray icon preferences

### Data Persistence
Task data is stored in JSON format (`tasks.json`) for simple, human-readable persistence. The application loads and saves task data automatically, ensuring data integrity across sessions.

### Threading Architecture
The application uses Python's threading module to handle system tray operations and window management tasks without blocking the main GUI thread, ensuring responsive user interaction.

## External Dependencies

### GUI and Window Management
- **tkinter**: Primary GUI framework (built into Python)
- **win32gui, win32con, win32api**: Windows API access for advanced window management
- **ctypes**: Low-level Windows API integration

### System Integration
- **pystray**: System tray icon management and context menus
- **PIL (Pillow)**: Image creation and manipulation for tray icons

### Data Handling
- **json**: Configuration and task data serialization (built into Python)
- **datetime**: Task timestamp management (built into Python)
- **os**: File system operations (built into Python)

### Utility Libraries
- **threading**: Background task management (built into Python)